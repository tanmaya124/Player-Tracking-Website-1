The Azure IoT extension for Azure CLI. Intended for power users and/or automation of IoT solutions at scale.

